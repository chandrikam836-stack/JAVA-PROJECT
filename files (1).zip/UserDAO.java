package com.library.dao;

import com.library.model.User;
import com.library.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for the `users` and `user_genres` tables.
 */
public class UserDAO {

    // ── REGISTER ─────────────────────────────────────────────────────────────

    /**
     * Inserts a new user row.
     * @param user  User with passwordHash already set to a BCrypt hash.
     * @return true if the row was inserted.
     */
    public boolean registerUser(User user) throws SQLException {
        String sql = "INSERT INTO users "
            + "(first_name, last_name, email, username, password, avatar, "
            + " country, bio, reading_goal, pref_format) "
            + "VALUES (?,?,?,?,?,?,?,?,?,?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, user.getFirstName());
            ps.setString(2, user.getLastName());
            ps.setString(3, user.getEmail());
            ps.setString(4, user.getUsername());
            ps.setString(5, user.getPasswordHash());
            ps.setString(6, user.getAvatar());
            ps.setString(7, user.getCountry());
            ps.setString(8, user.getBio());
            ps.setInt(9,    user.getReadingGoal());
            ps.setString(10, user.getPrefFormat());

            int rows = ps.executeUpdate();
            if (rows > 0 && user.getGenres() != null && !user.getGenres().isEmpty()) {
                ResultSet keys = ps.getGeneratedKeys();
                if (keys.next()) {
                    int newId = keys.getInt(1);
                    user.setUserId(newId);
                    saveGenres(conn, newId, user.getGenres());
                }
            }
            return rows > 0;
        }
    }

    /** Saves genre preferences for a user (bulk insert). */
    private void saveGenres(Connection conn, int userId, List<String> genres) throws SQLException {
        String sql = "INSERT IGNORE INTO user_genres (user_id, genre) VALUES (?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            for (String g : genres) {
                ps.setInt(1, userId);
                ps.setString(2, g);
                ps.addBatch();
            }
            ps.executeBatch();
        }
    }

    // ── LOGIN / LOOKUP ────────────────────────────────────────────────────────

    /** Finds an active user by email (for login). */
    public User getUserByEmail(String email) throws SQLException {
        String sql = "SELECT * FROM users WHERE email = ? AND is_active = TRUE";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            return rs.next() ? mapUser(rs) : null;
        }
    }

    /** Finds an active user by user_id (for session validation). */
    public User getUserById(int userId) throws SQLException {
        String sql = "SELECT * FROM users WHERE user_id = ? AND is_active = TRUE";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                User u = mapUser(rs);
                u.setGenres(getGenresByUserId(userId));
                return u;
            }
            return null;
        }
    }

    /** Checks if an email is already registered. */
    public boolean emailExists(String email) throws SQLException {
        String sql = "SELECT COUNT(*) FROM users WHERE email = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            return rs.next() && rs.getInt(1) > 0;
        }
    }

    /** Checks if a username is already taken. */
    public boolean usernameExists(String username) throws SQLException {
        String sql = "SELECT COUNT(*) FROM users WHERE username = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            return rs.next() && rs.getInt(1) > 0;
        }
    }

    /** Returns genre preferences for a user. */
    public List<String> getGenresByUserId(int userId) throws SQLException {
        List<String> genres = new ArrayList<>();
        String sql = "SELECT genre FROM user_genres WHERE user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) genres.add(rs.getString("genre"));
        }
        return genres;
    }

    // ── HELPER ───────────────────────────────────────────────────────────────

    private User mapUser(ResultSet rs) throws SQLException {
        User u = new User();
        u.setUserId(rs.getInt("user_id"));
        u.setFirstName(rs.getString("first_name"));
        u.setLastName(rs.getString("last_name"));
        u.setEmail(rs.getString("email"));
        u.setUsername(rs.getString("username"));
        u.setPasswordHash(rs.getString("password"));
        u.setAvatar(rs.getString("avatar"));
        u.setCountry(rs.getString("country"));
        u.setBio(rs.getString("bio"));
        u.setReadingGoal(rs.getInt("reading_goal"));
        u.setPrefFormat(rs.getString("pref_format"));
        u.setActive(rs.getBoolean("is_active"));
        Date dob = rs.getDate("dob");
        if (dob != null) u.setDob(dob.toLocalDate());
        Timestamp joined = rs.getTimestamp("joined_date");
        if (joined != null) u.setJoinedDate(joined.toLocalDateTime());
        return u;
    }
}
