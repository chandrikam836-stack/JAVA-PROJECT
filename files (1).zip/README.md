# 📚 Library Management System — Full Stack Setup Guide

## Architecture

```
Browser (HTML/CSS/JS)
        │
        │  HTTP fetch() calls  →  /api/register, /api/login, /api/books, /api/favourites
        ▼
Apache Tomcat 10  (Java Servlets)
        │
        │  JDBC  (mysql-connector-java)
        ▼
MySQL 8.0  (library_db)
        ├── users
        ├── books
        ├── favourites
        ├── reading_history
        ├── user_genres
        └── notifications
```

---

## Step 1 — MySQL Setup

```bash
# Login to MySQL
mysql -u root -p

# Run the schema file
source /path/to/database/schema.sql
```

This creates the **library_db** database with all 6 tables and seeds 20 books.

---

## Step 2 — Update DB Password

Open `src/com/library/util/DBConnection.java` and change:

```java
private static final String DB_PASS = "your_password";   // ← set your MySQL password
```

---

## Step 3 — Build with Maven

```bash
cd LibraryManagementSystem
mvn clean package
```

This produces `target/LibraryManagementSystem-1.0.0.war`

### Dependencies (auto-downloaded by Maven)
| Dependency | Version | Purpose |
|---|---|---|
| `mysql-connector-java` | 8.0.33 | JDBC driver |
| `jbcrypt` | 0.4 | BCrypt password hashing |
| `org.json` | 20231013 | JSON parsing in servlets |
| `javax.servlet-api` | 4.0.1 | Servlet API (provided by Tomcat) |

---

## Step 4 — Deploy to Tomcat

```bash
# Copy WAR to Tomcat webapps directory
cp target/LibraryManagementSystem-1.0.0.war $TOMCAT_HOME/webapps/ROOT.war

# Start Tomcat
$TOMCAT_HOME/bin/startup.sh
```

Then open: **http://localhost:8080/**

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/register` | Register a new user (saves to MySQL) |
| `POST` | `/api/login` | Login — creates server session |
| `GET`  | `/api/login` | Check current session |
| `POST` | `/api/logout` | Destroy session |
| `GET`  | `/api/books` | All books from DB |
| `GET`  | `/api/books?search=moby` | Search by title/author |
| `GET`  | `/api/books?genre=Classic Literature` | Filter by genre |
| `GET`  | `/api/books?id=5` | Single book |
| `GET`  | `/api/favourites` | Get user's saved books |
| `POST` | `/api/favourites` | Add favourite `{"bookId":5}` |
| `DELETE` | `/api/favourites?bookId=5` | Remove favourite |

---

## Project Structure

```
LibraryManagementSystem/
├── database/
│   └── schema.sql                   ← Run this first
├── pom.xml                          ← Maven build
├── src/com/library/
│   ├── util/
│   │   └── DBConnection.java        ← JDBC connection
│   ├── model/
│   │   ├── User.java
│   │   ├── Book.java
│   │   └── Favourite.java
│   ├── dao/
│   │   ├── UserDAO.java             ← register, login, check email/username
│   │   ├── BookDAO.java             ← get all, search, by genre
│   │   └── FavouriteDAO.java        ← add, remove, list favourites
│   └── servlet/
│       ├── RegisterServlet.java     ← POST /api/register
│       ├── LoginServlet.java        ← POST+GET /api/login
│       ├── LogoutServlet.java       ← POST /api/logout
│       ├── BookServlet.java         ← GET /api/books
│       └── FavouriteServlet.java    ← GET/POST/DELETE /api/favourites
└── WebContent/
    └── index.html                   ← Full frontend (connects to all APIs)
```

---

## Frontend Changes (localStorage → Real API)

| Before (fake) | After (real) |
|---|---|
| `localStorage.setItem('lms_login','1')` | `fetch('/api/login', {method:'POST', body: JSON.stringify({email,password})})` |
| `localStorage.setItem('lms_user', ...)` | `fetch('/api/register', {method:'POST', body: JSON.stringify(userData)})` |
| `localStorage.removeItem('lms_login')` | `fetch('/api/logout', {method:'POST', credentials:'include'})` |
| `favIds` in localStorage | `fetch('/api/favourites')` — stored in MySQL `favourites` table |
| Hardcoded JS array (70 books) | `fetch('/api/books')` — loaded from MySQL `books` table |

---

## Security Notes

- Passwords are **BCrypt hashed** (cost factor 12) before storing in MySQL
- Sessions are managed server-side by Tomcat (`HttpSession`)
- All SQL queries use **PreparedStatements** (prevents SQL injection)
- Email and username uniqueness enforced at DB level with `UNIQUE` constraints
