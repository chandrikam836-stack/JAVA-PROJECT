package com.library.servlet;

import com.library.dao.BookDAO;
import com.library.model.Book;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

/**
 * GET /api/books               → all books
 * GET /api/books?search=moby   → search by title / author
 * GET /api/books?genre=Classic → filter by genre
 * GET /api/books?id=5          → single book
 */
@WebServlet("/api/books")
public class BookServlet extends HttpServlet {

    private final BookDAO bookDAO = new BookDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws IOException {

        res.setContentType("application/json;charset=UTF-8");
        res.setHeader("Access-Control-Allow-Origin", "*");
        PrintWriter out = res.getWriter();

        try {
            String idParam     = req.getParameter("id");
            String searchParam = req.getParameter("search");
            String genreParam  = req.getParameter("genre");

            if (idParam != null) {
                // ── Single book ──────────────────────────────────────────────
                Book b = bookDAO.getBookById(Integer.parseInt(idParam.trim()));
                if (b == null) {
                    res.setStatus(404);
                    out.write("{\"error\":\"Book not found\"}");
                } else {
                    out.write(b.toJson());
                }
                return;
            }

            List<Book> books;
            if (searchParam != null && !searchParam.trim().isEmpty()) {
                books = bookDAO.searchBooks(searchParam.trim());
            } else if (genreParam != null && !genreParam.trim().isEmpty()) {
                books = bookDAO.getBooksByGenre(genreParam.trim());
            } else {
                books = bookDAO.getAllBooks();
            }

            // Serialise list
            StringBuilder sb = new StringBuilder("[");
            for (int i = 0; i < books.size(); i++) {
                sb.append(books.get(i).toJson());
                if (i < books.size() - 1) sb.append(",");
            }
            sb.append("]");
            out.write(sb.toString());

        } catch (Exception e) {
            res.setStatus(500);
            out.write("{\"error\":\"Server error: " + e.getMessage() + "\"}");
        }
    }

    @Override
    protected void doOptions(HttpServletRequest req, HttpServletResponse res) {
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
        res.setHeader("Access-Control-Allow-Headers", "Content-Type");
        res.setStatus(204);
    }
}
