package com.library.servlet;

import com.library.dao.UserDAO;
import com.library.model.User;
import org.mindrot.jbcrypt.BCrypt;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.stream.Collectors;

import org.json.JSONObject;

/**
 * POST /api/login
 *
 * Request body (JSON):
 * { "email": "jane@example.com", "password": "plainText" }
 *
 * Response (JSON):
 * { "success": true,  "userId": 7, "username": "jane_reads", "firstName": "Jane", "avatar": "📚" }
 * { "success": false, "msg": "Invalid email or password" }
 *
 * GET /api/login  → returns current session user (or 401 if not logged in)
 * POST /api/logout → destroys the session
 */
@WebServlet("/api/login")
public class LoginServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAO();

    // ── POST: login ───────────────────────────────────────────────────────────
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws IOException {

        res.setContentType("application/json;charset=UTF-8");
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Credentials", "true");
        PrintWriter out = res.getWriter();

        try {
            String body = req.getReader().lines().collect(Collectors.joining());
            JSONObject data = new JSONObject(body);

            String email    = data.optString("email", "").trim().toLowerCase();
            String password = data.optString("password", "");

            if (email.isEmpty() || password.isEmpty()) {
                res.setStatus(400);
                out.write("{\"success\":false,\"msg\":\"Email and password are required.\"}");
                return;
            }

            User user = userDAO.getUserByEmail(email);
            if (user == null || !BCrypt.checkpw(password, user.getPasswordHash())) {
                res.setStatus(401);
                out.write("{\"success\":false,\"msg\":\"Invalid email or password.\"}");
                return;
            }

            // ── Create session ────────────────────────────────────────────────
            HttpSession session = req.getSession(true);
            session.setAttribute("userId",    user.getUserId());
            session.setAttribute("username",  user.getUsername());
            session.setAttribute("firstName", user.getFirstName());
            session.setAttribute("avatar",    user.getAvatar());

            out.write("{\"success\":true"
                + ",\"userId\":"     + user.getUserId()
                + ",\"username\":\"" + escJson(user.getUsername())  + "\""
                + ",\"firstName\":\"" + escJson(user.getFirstName()) + "\""
                + ",\"avatar\":\""   + escJson(user.getAvatar())    + "\""
                + "}");

        } catch (Exception e) {
            res.setStatus(500);
            out.write("{\"success\":false,\"msg\":\"Server error.\"}");
        }
    }

    // ── GET: check session ────────────────────────────────────────────────────
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws IOException {

        res.setContentType("application/json;charset=UTF-8");
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Credentials", "true");
        PrintWriter out = res.getWriter();

        HttpSession session = req.getSession(false);
        if (session != null && session.getAttribute("userId") != null) {
            out.write("{\"loggedIn\":true"
                + ",\"userId\":"     + session.getAttribute("userId")
                + ",\"username\":\"" + escJson((String) session.getAttribute("username"))  + "\""
                + ",\"firstName\":\"" + escJson((String) session.getAttribute("firstName")) + "\""
                + ",\"avatar\":\""   + escJson((String) session.getAttribute("avatar"))    + "\""
                + "}");
        } else {
            res.setStatus(401);
            out.write("{\"loggedIn\":false}");
        }
    }

    @Override
    protected void doOptions(HttpServletRequest req, HttpServletResponse res) {
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS");
        res.setHeader("Access-Control-Allow-Headers", "Content-Type");
        res.setHeader("Access-Control-Allow-Credentials", "true");
        res.setStatus(204);
    }

    private static String escJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
