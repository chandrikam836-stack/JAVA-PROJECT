package com.library.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public class User {

    private int           userId;
    private String        firstName;
    private String        lastName;
    private String        email;
    private String        username;
    private String        passwordHash;
    private String        avatar;
    private LocalDate     dob;
    private String        country;
    private String        bio;
    private int           readingGoal;
    private String        prefFormat;
    private LocalDateTime joinedDate;
    private boolean       active;
    private List<String>  genres;         // loaded separately from user_genres

    // ── Constructors ──────────────────────────────────────────────────────────

    public User() {}

    // ── Getters & Setters ─────────────────────────────────────────────────────

    public int           getUserId()       { return userId; }
    public void          setUserId(int v)  { this.userId = v; }

    public String        getFirstName()             { return firstName; }
    public void          setFirstName(String v)     { this.firstName = v; }

    public String        getLastName()              { return lastName; }
    public void          setLastName(String v)      { this.lastName = v; }

    public String        getEmail()                 { return email; }
    public void          setEmail(String v)         { this.email = v; }

    public String        getUsername()              { return username; }
    public void          setUsername(String v)      { this.username = v; }

    public String        getPasswordHash()          { return passwordHash; }
    public void          setPasswordHash(String v)  { this.passwordHash = v; }

    public String        getAvatar()                { return avatar; }
    public void          setAvatar(String v)        { this.avatar = v; }

    public LocalDate     getDob()                   { return dob; }
    public void          setDob(LocalDate v)        { this.dob = v; }

    public String        getCountry()               { return country; }
    public void          setCountry(String v)       { this.country = v; }

    public String        getBio()                   { return bio; }
    public void          setBio(String v)           { this.bio = v; }

    public int           getReadingGoal()           { return readingGoal; }
    public void          setReadingGoal(int v)      { this.readingGoal = v; }

    public String        getPrefFormat()            { return prefFormat; }
    public void          setPrefFormat(String v)    { this.prefFormat = v; }

    public LocalDateTime getJoinedDate()            { return joinedDate; }
    public void          setJoinedDate(LocalDateTime v) { this.joinedDate = v; }

    public boolean       isActive()                 { return active; }
    public void          setActive(boolean v)       { this.active = v; }

    public List<String>  getGenres()               { return genres; }
    public void          setGenres(List<String> v) { this.genres = v; }
}
