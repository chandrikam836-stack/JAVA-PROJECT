package com.library.model;

import java.time.LocalDateTime;

public class Favourite {

    private int           favId;
    private int           userId;
    private int           bookId;
    private LocalDateTime savedOn;
    private Book          book;   // populated via JOIN when needed

    public Favourite() {}

    public int    getFavId()              { return favId; }
    public void   setFavId(int v)         { this.favId = v; }

    public int    getUserId()             { return userId; }
    public void   setUserId(int v)        { this.userId = v; }

    public int    getBookId()             { return bookId; }
    public void   setBookId(int v)        { this.bookId = v; }

    public LocalDateTime getSavedOn()     { return savedOn; }
    public void          setSavedOn(LocalDateTime v){ this.savedOn = v; }

    public Book   getBook()               { return book; }
    public void   setBook(Book v)         { this.book = v; }
}
