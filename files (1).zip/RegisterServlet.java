package com.library.servlet;

import com.library.dao.UserDAO;
import com.library.model.User;
import com.library.util.DBConnection;
import org.mindrot.jbcrypt.BCrypt;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * POST /api/register
 *
 * Request body (JSON):
 * {
 *   "firstName":  "Jane",
 *   "lastName":   "Austen",
 *   "email":      "jane@example.com",
 *   "username":   "jane_reads",
 *   "password":   "plainText",
 *   "avatar":     "📚",
 *   "country":    "United Kingdom",
 *   "bio":        "...",
 *   "readingGoal": 12,
 *   "prefFormat": "epub",
 *   "genres":     ["Classic Literature","Adventure & Mystery"]
 * }
 *
 * Response (JSON):
 * { "success": true,  "userId": 7,  "username": "jane_reads" }
 * { "success": false, "msg": "Email already registered" }
 */
@WebServlet("/api/register")
public class RegisterServlet extends HttpServlet {

    private final UserDAO userDAO = new UserDAO();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws IOException {

        res.setContentType("application/json;charset=UTF-8");
        res.setHeader("Access-Control-Allow-Origin", "*");
        PrintWriter out = res.getWriter();

        try {
            // ── Parse JSON body ──────────────────────────────────────────────
            String body = req.getReader().lines().collect(Collectors.joining());
            JSONObject data = new JSONObject(body);

            String email    = data.getString("email").trim().toLowerCase();
            String username = data.getString("username").trim();
            String password = data.getString("password");

            // ── Validation ───────────────────────────────────────────────────
            if (email.isEmpty() || username.isEmpty() || password.length() < 8) {
                out.write("{\"success\":false,\"msg\":\"Invalid input data.\"}");
                return;
            }
            if (userDAO.emailExists(email)) {
                out.write("{\"success\":false,\"msg\":\"Email already registered.\"}");
                return;
            }
            if (userDAO.usernameExists(username)) {
                out.write("{\"success\":false,\"msg\":\"Username already taken.\"}");
                return;
            }

            // ── Build User object ────────────────────────────────────────────
            User user = new User();
            user.setFirstName(data.optString("firstName", "").trim());
            user.setLastName(data.optString("lastName", "").trim());
            user.setEmail(email);
            user.setUsername(username);
            user.setPasswordHash(BCrypt.hashpw(password, BCrypt.gensalt(12)));
            user.setAvatar(data.optString("avatar", "📚"));
            user.setCountry(data.optString("country", null));
            user.setBio(data.optString("bio", null));
            user.setReadingGoal(data.optInt("readingGoal", 12));
            user.setPrefFormat(data.optString("prefFormat", null));

            // Parse genres array
            List<String> genres = new ArrayList<>();
            JSONArray genreArr = data.optJSONArray("genres");
            if (genreArr != null) {
                for (int i = 0; i < genreArr.length(); i++) {
                    genres.add(genreArr.getString(i));
                }
            }
            user.setGenres(genres);

            // ── Persist ───────────────────────────────────────────────────────
            boolean ok = userDAO.registerUser(user);
            if (ok) {
                // Create session
                HttpSession session = req.getSession(true);
                session.setAttribute("userId", user.getUserId());
                session.setAttribute("username", user.getUsername());
                session.setAttribute("firstName", user.getFirstName());
                session.setAttribute("avatar", user.getAvatar());

                out.write("{\"success\":true"
                    + ",\"userId\":"    + user.getUserId()
                    + ",\"username\":\"" + escJson(user.getUsername()) + "\""
                    + ",\"firstName\":\"" + escJson(user.getFirstName()) + "\""
                    + ",\"avatar\":\"" + escJson(user.getAvatar()) + "\""
                    + "}");
            } else {
                res.setStatus(500);
                out.write("{\"success\":false,\"msg\":\"Registration failed. Please try again.\"}");
            }

        } catch (Exception e) {
            res.setStatus(500);
            out.write("{\"success\":false,\"msg\":\"Server error: " + escJson(e.getMessage()) + "\"}");
        }
    }

    @Override
    protected void doOptions(HttpServletRequest req, HttpServletResponse res) {
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
        res.setHeader("Access-Control-Allow-Headers", "Content-Type");
        res.setStatus(204);
    }

    private static String escJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
