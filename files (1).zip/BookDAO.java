package com.library.dao;

import com.library.model.Book;
import com.library.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for the `books` table.
 */
public class BookDAO {

    // ── READ ──────────────────────────────────────────────────────────────────

    /** Returns all books ordered by title. */
    public List<Book> getAllBooks() throws SQLException {
        List<Book> list = new ArrayList<>();
        String sql = "SELECT * FROM books ORDER BY title";
        try (Connection conn = DBConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(mapBook(rs));
        }
        return list;
    }

    /** Returns a single book by its primary key. */
    public Book getBookById(int bookId) throws SQLException {
        String sql = "SELECT * FROM books WHERE book_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, bookId);
            ResultSet rs = ps.executeQuery();
            return rs.next() ? mapBook(rs) : null;
        }
    }

    /**
     * Full-text search across title AND author.
     * @param query  Raw search term (LIKE wrapping applied internally)
     */
    public List<Book> searchBooks(String query) throws SQLException {
        List<Book> list = new ArrayList<>();
        String sql = "SELECT * FROM books WHERE title LIKE ? OR author LIKE ? ORDER BY title";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String q = "%" + query + "%";
            ps.setString(1, q);
            ps.setString(2, q);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapBook(rs));
        }
        return list;
    }

    /** Returns all books that belong to a specific genre. */
    public List<Book> getBooksByGenre(String genre) throws SQLException {
        List<Book> list = new ArrayList<>();
        String sql = "SELECT * FROM books WHERE genre = ? ORDER BY title";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, genre);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapBook(rs));
        }
        return list;
    }

    /** Returns the N most recently added books. */
    public List<Book> getRecentBooks(int limit) throws SQLException {
        List<Book> list = new ArrayList<>();
        String sql = "SELECT * FROM books ORDER BY added_date DESC LIMIT ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapBook(rs));
        }
        return list;
    }

    // ── WRITE ─────────────────────────────────────────────────────────────────

    /** Inserts a new book and returns its generated book_id. */
    public int addBook(Book book) throws SQLException {
        String sql = "INSERT INTO books "
            + "(title, author, year_pub, genre, cover_url, read_url, pdf_url, epub_url, source, description) "
            + "VALUES (?,?,?,?,?,?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, book.getTitle());
            ps.setString(2, book.getAuthor());
            if (book.getYearPub() != null) ps.setInt(3, book.getYearPub()); else ps.setNull(3, Types.INTEGER);
            ps.setString(4, book.getGenre());
            ps.setString(5, book.getCoverUrl());
            ps.setString(6, book.getReadUrl());
            ps.setString(7, book.getPdfUrl());
            ps.setString(8, book.getEpubUrl());
            ps.setString(9, book.getSource());
            ps.setString(10, book.getDescription());
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            return keys.next() ? keys.getInt(1) : -1;
        }
    }

    // ── HELPER ───────────────────────────────────────────────────────────────

    private Book mapBook(ResultSet rs) throws SQLException {
        Book b = new Book();
        b.setBookId(rs.getInt("book_id"));
        b.setTitle(rs.getString("title"));
        b.setAuthor(rs.getString("author"));
        int yr = rs.getInt("year_pub");
        if (!rs.wasNull()) b.setYearPub(yr);
        b.setGenre(rs.getString("genre"));
        b.setCoverUrl(rs.getString("cover_url"));
        b.setReadUrl(rs.getString("read_url"));
        b.setPdfUrl(rs.getString("pdf_url"));
        b.setEpubUrl(rs.getString("epub_url"));
        b.setSource(rs.getString("source"));
        b.setDescription(rs.getString("description"));
        Timestamp ts = rs.getTimestamp("added_date");
        if (ts != null) b.setAddedDate(ts.toLocalDateTime());
        return b;
    }
}
