package com.library.dao;

import com.library.model.Book;
import com.library.model.Favourite;
import com.library.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for the `favourites` table.
 */
public class FavouriteDAO {

    /** Saves a book as a favourite for a user. Silently ignores duplicates. */
    public boolean addFavourite(int userId, int bookId) throws SQLException {
        String sql = "INSERT IGNORE INTO favourites (user_id, book_id) VALUES (?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, bookId);
            return ps.executeUpdate() > 0;
        }
    }

    /** Removes a favourite. */
    public boolean removeFavourite(int userId, int bookId) throws SQLException {
        String sql = "DELETE FROM favourites WHERE user_id = ? AND book_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, bookId);
            return ps.executeUpdate() > 0;
        }
    }

    /** Returns all favourite books for a user (joined with book details). */
    public List<Favourite> getFavouritesByUser(int userId) throws SQLException {
        List<Favourite> list = new ArrayList<>();
        String sql = "SELECT f.fav_id, f.user_id, f.book_id, f.saved_on, "
            + "b.title, b.author, b.year_pub, b.genre, b.cover_url, "
            + "b.read_url, b.pdf_url, b.epub_url, b.source, b.description "
            + "FROM favourites f "
            + "JOIN books b ON f.book_id = b.book_id "
            + "WHERE f.user_id = ? "
            + "ORDER BY f.saved_on DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Favourite fav = new Favourite();
                fav.setFavId(rs.getInt("fav_id"));
                fav.setUserId(rs.getInt("user_id"));
                fav.setBookId(rs.getInt("book_id"));
                Timestamp ts = rs.getTimestamp("saved_on");
                if (ts != null) fav.setSavedOn(ts.toLocalDateTime());

                // Populate nested book
                Book b = new Book();
                b.setBookId(rs.getInt("book_id"));
                b.setTitle(rs.getString("title"));
                b.setAuthor(rs.getString("author"));
                int yr = rs.getInt("year_pub");
                if (!rs.wasNull()) b.setYearPub(yr);
                b.setGenre(rs.getString("genre"));
                b.setCoverUrl(rs.getString("cover_url"));
                b.setReadUrl(rs.getString("read_url"));
                b.setPdfUrl(rs.getString("pdf_url"));
                b.setEpubUrl(rs.getString("epub_url"));
                b.setSource(rs.getString("source"));
                b.setDescription(rs.getString("description"));
                fav.setBook(b);

                list.add(fav);
            }
        }
        return list;
    }

    /** Returns true if the user has already saved this book. */
    public boolean isFavourite(int userId, int bookId) throws SQLException {
        String sql = "SELECT 1 FROM favourites WHERE user_id = ? AND book_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            ps.setInt(2, bookId);
            return ps.executeQuery().next();
        }
    }
}
