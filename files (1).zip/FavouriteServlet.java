package com.library.servlet;

import com.library.dao.FavouriteDAO;
import com.library.model.Favourite;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.stream.Collectors;

import org.json.JSONObject;

/**
 * GET    /api/favourites           → list favourites for the logged-in user
 * POST   /api/favourites           → {"bookId": 5}  add favourite
 * DELETE /api/favourites?bookId=5  → remove favourite
 */
@WebServlet("/api/favourites")
public class FavouriteServlet extends HttpServlet {

    private final FavouriteDAO favDAO = new FavouriteDAO();

    // ── GET: list ─────────────────────────────────────────────────────────────
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws IOException {

        res.setContentType("application/json;charset=UTF-8");
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Credentials", "true");
        PrintWriter out = res.getWriter();

        Integer userId = getSessionUserId(req);
        if (userId == null) { res.setStatus(401); out.write("{\"error\":\"Not logged in\"}"); return; }

        try {
            List<Favourite> favs = favDAO.getFavouritesByUser(userId);
            StringBuilder sb = new StringBuilder("[");
            for (int i = 0; i < favs.size(); i++) {
                Favourite f = favs.get(i);
                sb.append(f.getBook() != null ? f.getBook().toJson() : "{}");
                if (i < favs.size() - 1) sb.append(",");
            }
            sb.append("]");
            out.write(sb.toString());
        } catch (Exception e) {
            res.setStatus(500);
            out.write("{\"error\":\"" + e.getMessage() + "\"}");
        }
    }

    // ── POST: add ─────────────────────────────────────────────────────────────
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws IOException {

        res.setContentType("application/json;charset=UTF-8");
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Credentials", "true");
        PrintWriter out = res.getWriter();

        Integer userId = getSessionUserId(req);
        if (userId == null) { res.setStatus(401); out.write("{\"error\":\"Not logged in\"}"); return; }

        try {
            String body = req.getReader().lines().collect(Collectors.joining());
            int bookId = new JSONObject(body).getInt("bookId");
            boolean ok = favDAO.addFavourite(userId, bookId);
            out.write("{\"success\":" + ok + "}");
        } catch (Exception e) {
            res.setStatus(500);
            out.write("{\"error\":\"" + e.getMessage() + "\"}");
        }
    }

    // ── DELETE: remove ────────────────────────────────────────────────────────
    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse res)
            throws IOException {

        res.setContentType("application/json;charset=UTF-8");
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Credentials", "true");
        PrintWriter out = res.getWriter();

        Integer userId = getSessionUserId(req);
        if (userId == null) { res.setStatus(401); out.write("{\"error\":\"Not logged in\"}"); return; }

        try {
            int bookId = Integer.parseInt(req.getParameter("bookId"));
            boolean ok = favDAO.removeFavourite(userId, bookId);
            out.write("{\"success\":" + ok + "}");
        } catch (Exception e) {
            res.setStatus(500);
            out.write("{\"error\":\"" + e.getMessage() + "\"}");
        }
    }

    @Override
    protected void doOptions(HttpServletRequest req, HttpServletResponse res) {
        res.setHeader("Access-Control-Allow-Origin", "*");
        res.setHeader("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS");
        res.setHeader("Access-Control-Allow-Headers", "Content-Type");
        res.setHeader("Access-Control-Allow-Credentials", "true");
        res.setStatus(204);
    }

    private Integer getSessionUserId(HttpServletRequest req) {
        HttpSession s = req.getSession(false);
        if (s == null) return null;
        Object id = s.getAttribute("userId");
        return (id instanceof Integer) ? (Integer) id : null;
    }
}
